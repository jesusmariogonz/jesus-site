-- =====================================================================
--
--   R E C E T A R I O   S Q L   P A R A   R E T A I L
--   22 consultas de negocio resueltas sobre datos de punto de venta
--
--   Jesús González
--   https://jesus-site-silk.vercel.app/
--
-- ---------------------------------------------------------------------
--
--   CÓMO USAR ESTE ARCHIVO
--
--   Cada receta es autónoma: se copia y se ejecuta tal cual sobre el
--   dataset incluido en 01-Dataset-Retail-SQL.zip. Están escritas en
--   dialecto DuckDB porque es el que corre sin instalar un servidor;
--   donde algo cambia entre motores, la receta lo dice en su bloque
--   de NOTAS DE DIALECTO.
--
--   Los comentarios no son relleno: explican por qué la consulta está
--   escrita así y qué error concreto evita. Esa parte es la que no
--   encuentras en un tutorial.
--
--   TABLAS
--     fact_ventas       grano = línea de ticket
--     fact_inventario   grano = corte semanal por tienda y producto
--     dim_tienda / dim_producto / dim_cajero / dim_cliente
--     dim_calendario / metas
--
--   ÍNDICE
--     01 · Venta, tickets y ticket promedio
--     02 · Descomponer el ticket promedio
--     03 · Margen por categoría
--     04 · Curva horaria y patrón semanal
--     05 · Venta de mismas tiendas
--     06 · Crecimiento mensual contra el año anterior
--     07 · Cumplimiento de meta por tienda
--     08 · Ranking normalizado por superficie
--     09 · Participación dentro de su región
--     10 · Los que mandan y los que estorban
--     11 · Concentración del surtido
--     12 · Mezcla por formato de tienda
--     13 · Qué se compra junto con qué
--     14 · Tamaño de canasta y su efecto en el margen
--     15 · Productos ancla
--     16 · Cobertura del programa de lealtad
--     17 · Cohortes de retención
--     18 · Segmentación RFM
--     19 · Valor por nivel del programa
--     20 · Rotación y días de inventario
--     21 · Quiebres de existencia y venta perdida
--     22 · Días fuera de rango por tienda
--
-- =====================================================================




-- =====================================================================
--  FUNDAMENTOS DEL PUNTO DE VENTA
-- =====================================================================


-- ---------------------------------------------------------------------
--  01 · Venta, tickets y ticket promedio
--
--  ¿Cuánto vendimos, en cuántas transacciones y de cuánto fue el
--  ticket promedio?
-- ---------------------------------------------------------------------

SELECT
    COUNT(DISTINCT v.ticket_id)                                   AS tickets,
    SUM(v.cantidad)                                               AS unidades,
    SUM(v.cantidad * v.precio_unitario - v.descuento)             AS venta_neta,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / COUNT(DISTINCT v.ticket_id)                             AS ticket_promedio,
    SUM(v.cantidad) * 1.0 / COUNT(DISTINCT v.ticket_id)           AS unidades_por_ticket
FROM fact_ventas v
WHERE v.fecha >= DATE '2026-01-01';

-- NOTAS
--   El error más frecuente en punto de venta es contar filas y llamarles
--   tickets. La tabla está al grano de línea, así que COUNT(*) devuelve
--   líneas, no transacciones. Siempre COUNT(DISTINCT ticket_id).
--


-- ---------------------------------------------------------------------
--  02 · Descomponer el ticket promedio
--
--  El ticket subió, ¿fue porque vendimos cosas más caras o porque
--  vendimos más cosas?
-- ---------------------------------------------------------------------

SELECT
    c.anio_mes,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / COUNT(DISTINCT v.ticket_id)                    AS ticket_promedio,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / SUM(v.cantidad)                                AS precio_promedio,
    SUM(v.cantidad) * 1.0
        / COUNT(DISTINCT v.ticket_id)                    AS unidades_por_ticket
FROM fact_ventas v
JOIN dim_calendario c ON c.fecha = v.fecha
GROUP BY c.anio_mes
ORDER BY c.anio_mes;

-- NOTAS
--   Ticket promedio = precio promedio x unidades por ticket. Son dos
--   palancas distintas con dueños distintos: el precio lo mueve
--   categoría o mercadotecnia; las unidades por ticket las mueve la
--   operación de la tienda. Reportar solo el ticket sin descomponerlo no
--   le dice a nadie qué hacer.
--


-- ---------------------------------------------------------------------
--  03 · Margen por categoría
--
--  ¿Qué categorías dejan dinero y cuáles solo mueven volumen?
-- ---------------------------------------------------------------------

SELECT
    p.categoria,
    SUM(v.cantidad * v.precio_unitario - v.descuento)               AS venta_neta,
    SUM(v.cantidad * v.costo_unitario)                              AS costo,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        - SUM(v.cantidad * v.costo_unitario)                        AS margen,
    (SUM(v.cantidad * v.precio_unitario - v.descuento)
        - SUM(v.cantidad * v.costo_unitario))
        / NULLIF(SUM(v.cantidad * v.precio_unitario - v.descuento), 0) AS margen_pct,
    SUM(v.descuento)
        / NULLIF(SUM(v.cantidad * v.precio_unitario), 0)            AS tasa_descuento
FROM fact_ventas v
JOIN dim_producto p ON p.producto_id = v.producto_id
GROUP BY p.categoria
ORDER BY margen DESC;

-- NOTAS
--   NULLIF en todos los denominadores. Un filtro que deje una categoría
--   sin venta produce división entre cero y tumba la consulta completa,
--   no solo esa fila.
--


-- ---------------------------------------------------------------------
--  04 · Curva horaria y patrón semanal
--
--  ¿A qué hora y qué días necesitamos más gente en piso?
-- ---------------------------------------------------------------------

SELECT
    v.hora,
    COUNT(DISTINCT CASE WHEN c.es_fin_de_semana
                        THEN v.ticket_id END)          AS tickets_fin_semana,
    COUNT(DISTINCT CASE WHEN NOT c.es_fin_de_semana
                        THEN v.ticket_id END)          AS tickets_entre_semana,
    SUM(v.cantidad * v.precio_unitario - v.descuento)  AS venta_neta
FROM fact_ventas v
JOIN dim_calendario c ON c.fecha = v.fecha
GROUP BY v.hora
ORDER BY v.hora;

-- NOTAS
--   COUNT(DISTINCT CASE WHEN ...) es el patrón para contar transacciones
--   de un subconjunto sin repetir la consulta. Este resultado se traduce
--   directo a horarios de personal, que es de los pocos análisis que
--   ahorra dinero el mismo mes.
--


-- =====================================================================
--  COMPARABLES Y CRECIMIENTO
-- =====================================================================


-- ---------------------------------------------------------------------
--  05 · Venta de mismas tiendas
--
--  ¿Estamos creciendo de verdad, o solo porque abrimos sucursales?
-- ---------------------------------------------------------------------

WITH periodo AS (
    SELECT DATE '2026-01-01' AS ini, DATE '2026-06-30' AS fin
),
comparables AS (
    -- una tienda es comparable si ya operaba 365 días antes del inicio del periodo
    SELECT t.tienda_id
    FROM dim_tienda t, periodo p
    WHERE t.fecha_apertura <= p.ini - INTERVAL 365 DAY
),
actual AS (
    SELECT SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta
    FROM fact_ventas v, periodo p
    WHERE v.tienda_id IN (SELECT tienda_id FROM comparables)
      AND v.fecha BETWEEN p.ini AND p.fin
),
anterior AS (
    SELECT SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta
    FROM fact_ventas v, periodo p
    WHERE v.tienda_id IN (SELECT tienda_id FROM comparables)
      AND v.fecha BETWEEN p.ini - INTERVAL 365 DAY AND p.fin - INTERVAL 365 DAY
)
SELECT
    (SELECT COUNT(*) FROM comparables)                       AS tiendas_comparables,
    a.venta                                                  AS venta_actual,
    n.venta                                                  AS venta_anterior,
    a.venta - n.venta                                        AS variacion,
    (a.venta - n.venta) / NULLIF(n.venta, 0)                 AS crecimiento_mismas_tiendas
FROM actual a, anterior n;

-- NOTAS
--   El detalle que casi todas las implementaciones se equivocan: el
--   conjunto de tiendas comparables se define UNA sola vez, con la fecha
--   del periodo actual, y se aplica idéntico a los dos lados. Si dejas
--   que se recalcule en el periodo anterior, estás comparando un grupo
--   de tiendas contra otro distinto y el número no significa nada.
--
-- NOTAS DE DIALECTO
--   INTERVAL 365 DAY funciona en DuckDB, Databricks y Postgres. En SQL
--   Server: DATEADD(DAY, -365, p.ini). En Snowflake: DATEADD(DAY, -365,
--   p.ini) o p.ini - 365.


-- ---------------------------------------------------------------------
--  06 · Crecimiento mensual contra el año anterior
--
--  ¿Cómo va cada mes contra el mismo mes del año pasado?
-- ---------------------------------------------------------------------

WITH mensual AS (
    SELECT
        c.anio,
        c.numero_mes,
        SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta
    FROM fact_ventas v
    JOIN dim_calendario c ON c.fecha = v.fecha
    GROUP BY c.anio, c.numero_mes
)
SELECT
    m.anio,
    m.numero_mes,
    m.venta                                        AS venta_actual,
    aa.venta                                       AS venta_anio_anterior,
    (m.venta - aa.venta) / NULLIF(aa.venta, 0)     AS crecimiento
FROM mensual m
LEFT JOIN mensual aa
       ON aa.anio = m.anio - 1
      AND aa.numero_mes = m.numero_mes
ORDER BY m.anio, m.numero_mes;

-- NOTAS
--   El LEFT JOIN de la tabla contra sí misma desplazada un año es más
--   portable y más rápido que LAG con 12 posiciones, y no se rompe si
--   falta un mes intermedio.
--


-- ---------------------------------------------------------------------
--  07 · Cumplimiento de meta por tienda
--
--  ¿Qué tiendas van abajo de su meta y por cuánto?
-- ---------------------------------------------------------------------

SELECT
    t.tienda,
    t.region,
    c.anio_mes,
    SUM(v.cantidad * v.precio_unitario - v.descuento)          AS venta,
    MAX(m.meta_venta)                                          AS meta,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / NULLIF(MAX(m.meta_venta), 0)                         AS cumplimiento,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        - MAX(m.meta_venta)                                    AS brecha
FROM fact_ventas v
JOIN dim_calendario c ON c.fecha = v.fecha
JOIN dim_tienda t     ON t.tienda_id = v.tienda_id
LEFT JOIN metas m     ON m.tienda_id = v.tienda_id
                     AND m.mes_orden = c.mes_orden
WHERE c.anio_mes = '2026-05'
GROUP BY t.tienda, t.region, c.anio_mes
ORDER BY cumplimiento;

-- NOTAS
--   La meta está al grano mensual y la venta al grano diario. Si haces
--   el JOIN por fecha exacta, la meta solo aparece el día primero. Se
--   une por mes_orden y se toma con MAX para que el GROUP BY no la
--   multiplique por cada día del mes.
--


-- =====================================================================
--  DESEMPEÑO DE TIENDAS
-- =====================================================================


-- ---------------------------------------------------------------------
--  08 · Ranking normalizado por superficie
--
--  ¿Qué tienda aprovecha mejor el espacio que tiene?
-- ---------------------------------------------------------------------

WITH base AS (
    SELECT
        t.tienda_id,
        t.tienda,
        t.formato,
        t.plaza,
        t.metros_cuadrados,
        SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta,
        COUNT(DISTINCT v.ticket_id)                       AS tickets,
        COUNT(DISTINCT v.fecha)                           AS dias_con_venta
    FROM fact_ventas v
    JOIN dim_tienda t ON t.tienda_id = v.tienda_id
    WHERE v.fecha >= DATE '2026-01-01'
    GROUP BY t.tienda_id, t.tienda, t.formato, t.plaza, t.metros_cuadrados
)
SELECT
    tienda,
    formato,
    venta,
    venta / metros_cuadrados                          AS venta_por_m2,
    venta / dias_con_venta                            AS venta_diaria_promedio,
    tickets * 1.0 / dias_con_venta                    AS tickets_por_dia,
    RANK() OVER (ORDER BY venta DESC)                 AS rank_venta,
    RANK() OVER (ORDER BY venta / metros_cuadrados DESC) AS rank_productividad,
    RANK() OVER (PARTITION BY formato
                 ORDER BY venta / metros_cuadrados DESC) AS rank_en_su_formato
FROM base
ORDER BY venta_por_m2 DESC;

-- NOTAS
--   Comparar tiendas por venta absoluta siempre lo ganan las grandes, y
--   eso no lleva a ninguna decisión. La diferencia entre rank_venta y
--   rank_productividad es la columna más útil de esta consulta: una
--   tienda que baja diez lugares al normalizar por metros es una tienda
--   grande que rinde poco.
--


-- ---------------------------------------------------------------------
--  09 · Participación dentro de su región
--
--  ¿Cuánto pesa cada tienda dentro de su propia región?
-- ---------------------------------------------------------------------

SELECT
    t.region,
    t.tienda,
    SUM(v.cantidad * v.precio_unitario - v.descuento)  AS venta,
    SUM(SUM(v.cantidad * v.precio_unitario - v.descuento))
        OVER (PARTITION BY t.region)                   AS venta_region,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / SUM(SUM(v.cantidad * v.precio_unitario - v.descuento))
          OVER (PARTITION BY t.region)                 AS participacion_region
FROM fact_ventas v
JOIN dim_tienda t ON t.tienda_id = v.tienda_id
GROUP BY t.region, t.tienda
ORDER BY t.region, participacion_region DESC;

-- NOTAS
--   Una función de ventana sobre una agregación (SUM sobre SUM) evita el
--   subquery y la segunda pasada por la tabla. Es el patrón que más
--   rápido distingue a alguien que sabe SQL de alguien que lo está
--   aprendiendo.
--


-- =====================================================================
--  PRODUCTO Y SURTIDO
-- =====================================================================


-- ---------------------------------------------------------------------
--  10 · Los que mandan y los que estorban
--
--  ¿Qué productos concentran la venta y cuáles no justifican su
--  espacio?
-- ---------------------------------------------------------------------

WITH prod AS (
    SELECT
        p.producto_id,
        p.producto,
        p.categoria,
        SUM(v.cantidad)                                    AS unidades,
        SUM(v.cantidad * v.precio_unitario - v.descuento)  AS venta,
        SUM(v.cantidad * v.precio_unitario - v.descuento)
            - SUM(v.cantidad * v.costo_unitario)           AS margen
    FROM fact_ventas v
    JOIN dim_producto p ON p.producto_id = v.producto_id
    WHERE v.fecha >= DATE '2025-07-01'
    GROUP BY p.producto_id, p.producto, p.categoria
),
acum AS (
    SELECT
        producto, categoria, unidades, venta, margen,
        ROW_NUMBER() OVER (ORDER BY venta DESC)              AS posicion,
        SUM(venta) OVER (ORDER BY venta DESC
                         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
            / SUM(venta) OVER ()                             AS venta_acumulada_pct
    FROM prod
)
SELECT
    posicion, producto, categoria, unidades, venta, margen,
    venta_acumulada_pct,
    CASE WHEN venta_acumulada_pct <= 0.50 THEN 'A · núcleo'
         WHEN venta_acumulada_pct <= 0.80 THEN 'B · soporte'
         ELSE 'C · cola larga' END                                     AS clase_abc
FROM acum
ORDER BY posicion;

-- NOTAS
--   Clasificación ABC clásica. El corte en 50% y 80% no es sagrado:
--   ajústalo a tu surtido. Lo que sí es constante es la lectura: los
--   productos de clase C no se eliminan automáticamente, porque algunos
--   son de destino (la gente entra por ellos y compra otras cosas).
--   Cruza siempre con análisis de canasta antes de descontinuar.
--


-- ---------------------------------------------------------------------
--  11 · Concentración del surtido
--
--  ¿Qué tan expuestos estamos a que falte un puñado de productos?
-- ---------------------------------------------------------------------

WITH prod AS (
    SELECT
        p.producto_id,
        SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta
    FROM fact_ventas v
    JOIN dim_producto p ON p.producto_id = v.producto_id
    GROUP BY p.producto_id
),
ordenado AS (
    SELECT venta, ROW_NUMBER() OVER (ORDER BY venta DESC) AS pos
    FROM prod
)
SELECT
    (SELECT COUNT(*) FROM prod)                                          AS skus_totales,
    SUM(CASE WHEN pos <= 10 THEN venta END) / SUM(venta)                 AS pct_top_10,
    SUM(CASE WHEN pos <= 20 THEN venta END) / SUM(venta)                 AS pct_top_20,
    SUM(CASE WHEN pos <= 50 THEN venta END) / SUM(venta)                 AS pct_top_50
FROM ordenado;

-- NOTAS
--   Si diez SKU explican más de la mitad de la venta, un desabasto de
--   esos diez es un problema de operación, no de compras. Este número
--   justifica presupuesto de inventario de seguridad mejor que cualquier
--   presentación.
--


-- ---------------------------------------------------------------------
--  12 · Mezcla por formato de tienda
--
--  ¿Vendemos lo mismo en una tienda de barrio que en una de
--  carretera?
-- ---------------------------------------------------------------------

SELECT
    p.categoria,
    SUM(CASE WHEN t.formato = 'Tradicional' THEN
        v.cantidad * v.precio_unitario - v.descuento END)
        / SUM(SUM(CASE WHEN t.formato = 'Tradicional' THEN
            v.cantidad * v.precio_unitario - v.descuento END)) OVER () AS mix_tradicional,
    SUM(CASE WHEN t.formato = 'Express' THEN
        v.cantidad * v.precio_unitario - v.descuento END)
        / SUM(SUM(CASE WHEN t.formato = 'Express' THEN
            v.cantidad * v.precio_unitario - v.descuento END)) OVER ()  AS mix_express,
    SUM(CASE WHEN t.formato = 'Estación' THEN
        v.cantidad * v.precio_unitario - v.descuento END)
        / SUM(SUM(CASE WHEN t.formato = 'Estación' THEN
            v.cantidad * v.precio_unitario - v.descuento END)) OVER ()  AS mix_estacion
FROM fact_ventas v
JOIN dim_producto p ON p.producto_id = v.producto_id
JOIN dim_tienda   t ON t.tienda_id = v.tienda_id
GROUP BY p.categoria
ORDER BY mix_tradicional DESC;

-- NOTAS
--   Comparar mezclas, no montos: cada formato tiene tamaños distintos,
--   así que los valores absolutos no se pueden poner lado a lado. Las
--   diferencias grandes entre columnas son las que justifican
--   planogramas distintos por formato.
--


-- =====================================================================
--  ANÁLISIS DE CANASTA
-- =====================================================================


-- ---------------------------------------------------------------------
--  13 · Qué se compra junto con qué
--
--  ¿Qué pares de categorías aparecen juntos en el mismo ticket?
-- ---------------------------------------------------------------------

WITH ticket_cat AS (
    SELECT DISTINCT v.ticket_id, p.categoria
    FROM fact_ventas v
    JOIN dim_producto p ON p.producto_id = v.producto_id
),
total AS (
    SELECT COUNT(DISTINCT ticket_id) AS n_tickets FROM ticket_cat
),
pares AS (
    SELECT
        a.categoria AS categoria_a,
        b.categoria AS categoria_b,
        COUNT(*)    AS tickets_juntos
    FROM ticket_cat a
    JOIN ticket_cat b
      ON a.ticket_id = b.ticket_id
     AND a.categoria < b.categoria      -- evita duplicar A-B y B-A
    GROUP BY a.categoria, b.categoria
),
soporte AS (
    SELECT categoria, COUNT(*) * 1.0 / (SELECT n_tickets FROM total) AS sop
    FROM ticket_cat
    GROUP BY categoria
)
SELECT
    p.categoria_a,
    p.categoria_b,
    p.tickets_juntos,
    p.tickets_juntos * 1.0 / (SELECT n_tickets FROM total)          AS soporte,
    p.tickets_juntos * 1.0 / (SELECT n_tickets FROM total)
        / (sa.sop * sb.sop)                                          AS lift
FROM pares p
JOIN soporte sa ON sa.categoria = p.categoria_a
JOIN soporte sb ON sb.categoria = p.categoria_b
WHERE p.tickets_juntos >= 30
ORDER BY lift DESC;

-- NOTAS
--   El JOIN de la tabla contra sí misma con la condición a.categoria <
--   b.categoria es el truco central: genera cada par una sola vez. El
--   lift mayor a 1 significa que esas dos categorías aparecen juntas más
--   de lo que el azar predeciría. Un lift alto con soporte bajo es una
--   curiosidad estadística, no una acción: filtra siempre por un mínimo
--   de tickets antes de tomarlo en serio.
--
--   Advertencia sobre el lift, que casi nadie menciona: penaliza a las
--   categorías muy frecuentes. Si Bebidas aparece en la mitad de los
--   tickets, su soporte individual es tan alto que el denominador
--   aplasta el lift de cualquier par que la incluya, aunque el par sea
--   real y valioso. Por eso conviene leer las tres columnas juntas. Un
--   par con lift 0.95 y 1,300 tickets en común mueve mucho más dinero
--   que uno con lift 2.4 y 40 tickets. El lift ordena; el soporte
--   dimensiona.
--


-- ---------------------------------------------------------------------
--  14 · Tamaño de canasta y su efecto en el margen
--
--  ¿Los tickets grandes son más rentables o solo más grandes?
-- ---------------------------------------------------------------------

WITH ticket AS (
    SELECT
        v.ticket_id,
        COUNT(*)                                            AS lineas,
        SUM(v.cantidad)                                     AS unidades,
        SUM(v.cantidad * v.precio_unitario - v.descuento)   AS venta,
        SUM(v.cantidad * v.precio_unitario - v.descuento)
            - SUM(v.cantidad * v.costo_unitario)            AS margen
    FROM fact_ventas v
    GROUP BY v.ticket_id
)
SELECT
    CASE WHEN lineas = 1 THEN '1 producto'
         WHEN lineas = 2 THEN '2 productos'
         WHEN lineas = 3 THEN '3 productos'
         ELSE '4 o más' END                    AS tamano_canasta,
    COUNT(*)                                   AS tickets,
    COUNT(*) * 1.0 / SUM(COUNT(*)) OVER ()     AS pct_tickets,
    AVG(venta)                                 AS ticket_promedio,
    SUM(venta)                                 AS venta_total,
    SUM(margen) / NULLIF(SUM(venta), 0)        AS margen_pct
FROM ticket
GROUP BY 1
ORDER BY 1;

-- NOTAS
--   En conveniencia la mayoría de los tickets son de uno o dos
--   productos, así que mover una fracción de ellos al siguiente escalón
--   tiene un efecto grande en la venta total. Esta tabla dimensiona esa
--   oportunidad antes de invertir en una promoción cruzada.
--
-- NOTAS DE DIALECTO
--   GROUP BY 1 (por posición) funciona en DuckDB, Snowflake, Databricks
--   y Postgres. SQL Server NO lo admite: hay que repetir la expresión
--   CASE completa en el GROUP BY.


-- ---------------------------------------------------------------------
--  15 · Productos ancla
--
--  ¿Qué producto trae gente que además compra otras cosas?
-- ---------------------------------------------------------------------

WITH ticket_prod AS (
    SELECT DISTINCT v.ticket_id, v.producto_id
    FROM fact_ventas v
),
ticket_tot AS (
    SELECT
        v.ticket_id,
        SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta_ticket,
        COUNT(DISTINCT v.producto_id)                     AS n_productos
    FROM fact_ventas v
    GROUP BY v.ticket_id
)
SELECT
    p.producto,
    p.categoria,
    COUNT(*)                                     AS tickets_donde_aparece,
    AVG(t.venta_ticket)              AS venta_promedio_del_ticket,
    AVG(t.n_productos)               AS productos_promedio_del_ticket,
    AVG(t.venta_ticket)
        - (SELECT AVG(venta_ticket) FROM ticket_tot) AS diferencia_vs_promedio
FROM ticket_prod tp
JOIN ticket_tot   t ON t.ticket_id = tp.ticket_id
JOIN dim_producto p ON p.producto_id = tp.producto_id
GROUP BY p.producto, p.categoria
HAVING COUNT(*) >= 100
ORDER BY diferencia_vs_promedio DESC;

-- NOTAS
--   Un producto ancla no es el que más vende: es aquel cuya presencia
--   coincide con tickets más grandes. Antes de descontinuar un producto
--   de clase C, revísalo aquí: puede ser la razón por la que el cliente
--   entró.
--


-- =====================================================================
--  CLIENTES Y LEALTAD
-- =====================================================================


-- ---------------------------------------------------------------------
--  16 · Cobertura del programa de lealtad
--
--  ¿Qué proporción de la venta logramos identificar?
-- ---------------------------------------------------------------------

SELECT
    c.anio_mes,
    COUNT(DISTINCT v.ticket_id)                              AS tickets_totales,
    COUNT(DISTINCT CASE WHEN v.cliente_id IS NOT NULL
                        THEN v.ticket_id END)                AS tickets_identificados,
    COUNT(DISTINCT CASE WHEN v.cliente_id IS NOT NULL
                        THEN v.ticket_id END) * 1.0
        / COUNT(DISTINCT v.ticket_id)                        AS cobertura,
    SUM(CASE WHEN v.cliente_id IS NOT NULL
             THEN v.cantidad * v.precio_unitario - v.descuento END)
        / SUM(v.cantidad * v.precio_unitario - v.descuento)  AS pct_venta_identificada
FROM fact_ventas v
JOIN dim_calendario c ON c.fecha = v.fecha
GROUP BY c.anio_mes
ORDER BY c.anio_mes;

-- NOTAS
--   La cobertura de identificación es el indicador que condiciona todos
--   los demás análisis de cliente. Con 40% de cobertura, cualquier
--   conclusión sobre comportamiento aplica solo a ese 40%, que además no
--   es una muestra aleatoria: son los más leales. Decláralo siempre
--   junto al resultado.
--


-- ---------------------------------------------------------------------
--  17 · Cohortes de retención
--
--  De los clientes que se dieron de alta en un mes, ¿cuántos siguen
--  comprando después?
-- ---------------------------------------------------------------------

WITH primera AS (
    SELECT
        v.cliente_id,
        MIN(v.fecha) AS fecha_primera
    FROM fact_ventas v
    WHERE v.cliente_id IS NOT NULL
    GROUP BY v.cliente_id
),
cohorte AS (
    SELECT
        p.cliente_id,
        STRFTIME(p.fecha_primera, '%Y-%m')                        AS cohorte_mes,
        DATE_DIFF('month', DATE_TRUNC('month', p.fecha_primera),
                           DATE_TRUNC('month', v.fecha))          AS mes_relativo
    FROM primera p
    JOIN fact_ventas v ON v.cliente_id = p.cliente_id
),
tam AS (
    SELECT cohorte_mes, COUNT(DISTINCT cliente_id) AS clientes_cohorte
    FROM cohorte
    WHERE mes_relativo = 0
    GROUP BY cohorte_mes
)
SELECT
    c.cohorte_mes,
    t.clientes_cohorte,
    c.mes_relativo,
    COUNT(DISTINCT c.cliente_id)                                  AS activos,
    COUNT(DISTINCT c.cliente_id) * 1.0 / t.clientes_cohorte       AS retencion
FROM cohorte c
JOIN tam t ON t.cohorte_mes = c.cohorte_mes
WHERE c.mes_relativo BETWEEN 0 AND 6
GROUP BY c.cohorte_mes, t.clientes_cohorte, c.mes_relativo
ORDER BY c.cohorte_mes, c.mes_relativo;

-- NOTAS
--   La cohorte se define por la PRIMERA compra observada, no por la
--   fecha de alta en el sistema. Son cosas distintas y confundirlas
--   infla la retención del mes cero. El mes_relativo 0 siempre da 100%
--   por construcción: es la validación de que la consulta está bien.
--
-- NOTAS DE DIALECTO
--   STRFTIME y DATE_DIFF son de DuckDB. Snowflake: TO_CHAR(fecha,'YYYY-
--   MM') y DATEDIFF(month, a, b). Databricks: DATE_FORMAT(fecha,'yyyy-
--   MM') y MONTHS_BETWEEN(b, a). SQL Server: FORMAT(fecha,'yyyy-MM') y
--   DATEDIFF(month, a, b).


-- ---------------------------------------------------------------------
--  18 · Segmentación RFM
--
--  ¿Quiénes son mis mejores clientes y quiénes se están yendo?
-- ---------------------------------------------------------------------

WITH corte AS (
    SELECT MAX(fecha) AS hoy FROM fact_ventas
),
base AS (
    SELECT
        v.cliente_id,
        DATE_DIFF('day', MAX(v.fecha), (SELECT hoy FROM corte))     AS recencia_dias,
        COUNT(DISTINCT v.ticket_id)                                 AS frecuencia,
        SUM(v.cantidad * v.precio_unitario - v.descuento)           AS monto
    FROM fact_ventas v
    WHERE v.cliente_id IS NOT NULL
    GROUP BY v.cliente_id
),
puntajes AS (
    SELECT
        b.*,
        NTILE(5) OVER (ORDER BY recencia_dias DESC) AS r,   -- menor recencia = mejor
        NTILE(5) OVER (ORDER BY frecuencia ASC)     AS f,
        NTILE(5) OVER (ORDER BY monto ASC)          AS m
    FROM base b
)
SELECT
    CASE
        WHEN r >= 4 AND f >= 4              THEN 'Campeones'
        WHEN r >= 3 AND f >= 3              THEN 'Leales'
        WHEN r >= 4 AND f <= 2              THEN 'Nuevos o prometedores'
        WHEN r <= 2 AND f >= 4              THEN 'En riesgo de fuga'
        WHEN r <= 2 AND f <= 2              THEN 'Dormidos'
        ELSE 'Ocasionales'
    END                                     AS segmento,
    COUNT(*)                                AS clientes,
    AVG(recencia_dias)                      AS recencia_promedio,
    AVG(frecuencia)                         AS frecuencia_promedio,
    AVG(monto)                              AS monto_promedio,
    SUM(monto)                              AS venta_total,
    SUM(monto) / SUM(SUM(monto)) OVER ()    AS pct_venta
FROM puntajes
GROUP BY 1
ORDER BY venta_total DESC;

-- NOTAS
--   NTILE(5) reparte a los clientes en quintiles. Ojo con la dirección
--   de cada orden: en recencia, menos días es mejor, por eso va DESC. Es
--   el error más común al implementar RFM y produce segmentos invertidos
--   que nadie nota hasta que la campaña se envía a los clientes
--   equivocados.
--
-- NOTAS DE DIALECTO
--   DATE_DIFF es de DuckDB. Snowflake y SQL Server: DATEDIFF(day, a, b).
--   Databricks: DATEDIFF(b, a) devuelve días directamente.


-- ---------------------------------------------------------------------
--  19 · Valor por nivel del programa
--
--  ¿Los niveles del programa realmente distinguen comportamientos
--  distintos?
-- ---------------------------------------------------------------------

SELECT
    cl.nivel,
    COUNT(DISTINCT cl.cliente_id)                         AS clientes,
    COUNT(DISTINCT v.ticket_id)                           AS tickets,
    COUNT(DISTINCT v.ticket_id) * 1.0
        / COUNT(DISTINCT cl.cliente_id)                   AS tickets_por_cliente,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / NULLIF(COUNT(DISTINCT v.ticket_id), 0)          AS ticket_promedio,
    SUM(v.cantidad * v.precio_unitario - v.descuento)
        / NULLIF(COUNT(DISTINCT cl.cliente_id), 0)        AS valor_por_cliente
FROM dim_cliente cl
LEFT JOIN fact_ventas v ON v.cliente_id = cl.cliente_id
GROUP BY cl.nivel
ORDER BY valor_por_cliente DESC;

-- NOTAS
--   El LEFT JOIN es deliberado: incluye a los clientes dados de alta que
--   nunca compraron. Con INNER JOIN desaparecen y el valor por cliente
--   sale inflado, que es exactamente el número que a nadie le conviene
--   revisar y todos reportan.
--


-- =====================================================================
--  INVENTARIO Y MERMA
-- =====================================================================


-- ---------------------------------------------------------------------
--  20 · Rotación y días de inventario
--
--  ¿Cuántas veces al año damos vuelta al inventario, y dónde está el
--  dinero parado?
-- ---------------------------------------------------------------------

WITH periodo AS (
    SELECT
        producto_id,
        tienda_id,
        SUM(unidades_vendidas)      AS vendidas,
        AVG(existencia_final)       AS existencia_promedio,
        COUNT(*)                    AS semanas
    FROM fact_inventario
    WHERE fecha_corte >= DATE '2025-07-01'
    GROUP BY producto_id, tienda_id
)
SELECT
    p.categoria,
    SUM(pe.vendidas)                                            AS unidades_vendidas,
    AVG(pe.existencia_promedio)                                 AS existencia_promedio,
    SUM(pe.vendidas) / NULLIF(SUM(pe.existencia_promedio), 0)   AS rotacion_periodo,
    365.0 / NULLIF(
        SUM(pe.vendidas) / NULLIF(SUM(pe.existencia_promedio), 0)
        * (365.0 / (MAX(pe.semanas) * 7.0)), 0)                 AS dias_de_inventario,
    SUM(pe.existencia_promedio * p.costo_unitario)              AS capital_inmovilizado
FROM periodo pe
JOIN dim_producto p ON p.producto_id = pe.producto_id
GROUP BY p.categoria
ORDER BY capital_inmovilizado DESC;

-- NOTAS
--   Las existencias son un SNAPSHOT: no se suman entre fechas, se
--   promedian. Sumarlas es el error clásico y produce números absurdos
--   que sin embargo nadie cuestiona porque «vienen del sistema». El
--   capital inmovilizado es la columna que abre conversaciones con
--   finanzas.
--


-- ---------------------------------------------------------------------
--  21 · Quiebres de existencia y venta perdida
--
--  ¿Cuánto nos costó no tener producto en el anaquel?
-- ---------------------------------------------------------------------

WITH quiebres AS (
    SELECT
        i.tienda_id,
        i.producto_id,
        COUNT(*)                                     AS cortes_totales,
        SUM(CASE WHEN i.existencia_final = 0
                 THEN 1 ELSE 0 END)                  AS cortes_sin_stock
    FROM fact_inventario i
    WHERE i.fecha_corte >= DATE '2025-07-01'
    GROUP BY i.tienda_id, i.producto_id
),
venta_semanal AS (
    SELECT
        i.tienda_id,
        i.producto_id,
        AVG(CASE WHEN i.existencia_final > 0
                 THEN i.unidades_vendidas END)      AS venta_sem_normal
    FROM fact_inventario i
    WHERE i.fecha_corte >= DATE '2025-07-01'
    GROUP BY i.tienda_id, i.producto_id
)
SELECT
    t.tienda,
    SUM(q.cortes_sin_stock)                           AS semanas_sin_stock,
    SUM(q.cortes_sin_stock) * 1.0
        / SUM(q.cortes_totales)                       AS tasa_quiebre,
    SUM(q.cortes_sin_stock * COALESCE(vs.venta_sem_normal, 0)
        * p.precio_lista)                             AS venta_perdida_estimada
FROM quiebres q
JOIN venta_semanal vs ON vs.tienda_id = q.tienda_id
                     AND vs.producto_id = q.producto_id
JOIN dim_tienda   t ON t.tienda_id = q.tienda_id
JOIN dim_producto p ON p.producto_id = q.producto_id
GROUP BY t.tienda
ORDER BY venta_perdida_estimada DESC;

-- NOTAS
--   La venta perdida es una ESTIMACIÓN, no un hecho: asume que el
--   cliente habría comprado a su ritmo normal y que no sustituyó por
--   otro producto. Preséntala siempre con esa etiqueta. Aun así, sirve
--   para priorizar: la tienda de arriba de la lista es donde conviene
--   revisar el proceso de resurtido primero.
--


-- =====================================================================
--  DETECCIÓN DE ANOMALÍAS
-- =====================================================================


-- ---------------------------------------------------------------------
--  22 · Días fuera de rango por tienda
--
--  ¿Qué días se salieron del comportamiento normal, y en qué tienda?
-- ---------------------------------------------------------------------

WITH diario AS (
    SELECT
        v.tienda_id,
        v.fecha,
        SUM(v.cantidad * v.precio_unitario - v.descuento) AS venta,
        COUNT(DISTINCT v.ticket_id)                       AS tickets
    FROM fact_ventas v
    GROUP BY v.tienda_id, v.fecha
),
estad AS (
    SELECT
        d.*,
        AVG(venta) OVER (PARTITION BY tienda_id
                         ORDER BY fecha
                         ROWS BETWEEN 28 PRECEDING AND 1 PRECEDING) AS media_movil,
        STDDEV_SAMP(venta) OVER (PARTITION BY tienda_id
                         ORDER BY fecha
                         ROWS BETWEEN 28 PRECEDING AND 1 PRECEDING) AS desv_movil
    FROM diario d
)
SELECT
    t.tienda,
    e.fecha,
    e.venta,
    e.media_movil,
    (e.venta - e.media_movil) / NULLIF(e.desv_movil, 0) AS z,
    CASE WHEN (e.venta - e.media_movil) / NULLIF(e.desv_movil, 0) > 3
              THEN 'Pico inusual'
         WHEN (e.venta - e.media_movil) / NULLIF(e.desv_movil, 0) < -3
              THEN 'Caída inusual'
    END                                            AS tipo
FROM estad e
JOIN dim_tienda t ON t.tienda_id = e.tienda_id
WHERE e.desv_movil > 0
  AND ABS((e.venta - e.media_movil) / NULLIF(e.desv_movil, 0)) > 3
ORDER BY ABS((e.venta - e.media_movil) / NULLIF(e.desv_movil, 0)) DESC;

-- NOTAS
--   La ventana excluye el día evaluado (termina en 1 PRECEDING). Si lo
--   incluyes, el propio valor anómalo contamina la media y la
--   desviación, y el método deja de detectar justo lo que buscabas. Un
--   umbral de 3 desviaciones es conservador: bájalo a 2.5 si quieres más
--   sensibilidad y estás dispuesto a revisar más falsos positivos.
--
-- NOTAS DE DIALECTO
--   STDDEV_SAMP funciona en DuckDB, Snowflake, Databricks y Postgres. En
--   SQL Server la función se llama STDEV().


-- =====================================================================
--  FIN DEL RECETARIO — 22 recetas
--  Jesús González · https://jesus-site-silk.vercel.app/
-- =====================================================================
